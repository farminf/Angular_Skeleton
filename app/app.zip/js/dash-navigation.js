'use strict';
var dashNavigation = angular.module('dashNavigation', []);


dashNavigation.controller( "dashNavigationController",  function() {});

//define the switch component
dashNavigation.component('dashNavigation',{
	//the component template
	templateUrl: 'templates/dash-nav.html'
});

function dashNavigationController(){}